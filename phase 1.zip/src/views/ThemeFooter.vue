<template>
   <section class="footer">
       <p class="text-center pt-2">All Right Reserved</p>
   </section>
</template>

<script>
export default {
    name: 'ThemeFooter'
}
</script>
<style scoped>
.footer {
  background-image: url('../assets/img/background.png');
  background-repeat: no-repeat;
  background-size: cover;
  min-height: 50px;
  color: #fff;
}

</style>