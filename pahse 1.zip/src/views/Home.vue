<template>
  <div class="home">
    <section class="firstSection">
      <h1 class="text-center">Frank's Garage</h1>
    </section>
    <!-- warehouse details  -->
    <div v-for="(detail, index) in details" :key="index" class="container">
      <h1 class="mt-5">{{detail.name}} <span class="location">{{detail.cars.location}}</span></h1>     
      <!-- vehicle details   -->
      <div class="vGrid mt-4">
        <div class="gridItem border vehicle" v-for="(vehicle, vehicleIndex) in detail.cars.vehicles" :class="'griditem'+ vehicleIndex" :key="vehicle._id">
          <!-- conditionally show image  -->
          <img class="carImg" :src="vehicle.img" v-if="vehicle.img" alt="No Preview" >
          <img class="carImg" :src="dummyImg" v-else alt="No Preview">
          <div class="p-3">
            <h3 class="make">{{vehicle.make}}</h3>
            <div class="modelDetails">
              <div class="model d-flex ">
                <p class="bold">Model:</p> <p class="price ml-auto ">{{vehicle.model}}</p>
              </div>
              <div class="price d-flex ">
                <p class="bold">Price:</p> <p class="price ml-auto "> &euro;{{vehicle.price}}</p>
              </div>              
            </div>
           <p class="dateAdded ml-auto ">{{vehicle.date_added}}</p>
            </div>            
          </div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import axios from 'axios';
export default {
  name: 'Home',
  data: ()  => ({
    details : String,
    dummyImg: require('@/assets/img/dummycar.png'),
  }),
  mounted () {
    axios
      .get('https://api.jsonbin.io/b/5ebe673947a2266b1478d892')
      .then(response => {
        var results;
        response.data.forEach(element => {
          element.cars.vehicles.sort((a,b) => {
            a = new Date(a.date_added); 
            b = new Date(b.date_added);
            results = a > b ? -1 : a < b ? 1 : 0;
            return results * -1
          })
        });
        this.details = response.data
      } )
  }
}
</script>
<style>
.firstSection {
  background-image: url('../assets/img/background.png');
  background-repeat: no-repeat;
  background-size: cover;
  min-height: 100px;
  color: #fff;
}

.firstSection h1 {
  padding-top: 23px;
}

.carImg{
  width: 100%;
  height: auto;
}

.location{
  font-size: 15px;
}

.location:before{
  content: '( '
}

.location:after {
  content: ' )'
}

.vGrid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    column-gap: 12px;
    row-gap: 12px;
}

p.dateAdded.ml-auto {
  font-size: 10px;
  color: grey;
  text-align: right;
  margin-top: 15px;
}

.modelDetails {
  margin-top: 25px
}
</style>